> This project is deprecated. Please check [react-webpack2-skeleton](https://github.com/velopert/react-webpack2-skeleton)


# REACT.JS Skeleton

This project is a React workspace that you can simply start working on React.js project right away.

React 0.14.7, Babel 6 and webpack on Node.js is used to setup the environment.

## How to use
- ``git clone https://github.com/velopert/react-skeleton.git`` - Clone the project
- ``npm install`` - Install the dependency
- ``npm start``  -Run the development server

*The default server port number is set to* **7777**

## How to use different port number
If there's another process which already took the port 7777 or you want to use different port number, you can specify different port number.
- ``npm start -- --port=[your favorite port]``
    - For example, you can type ``npm start -- --port=9999`` if you want to start the server in port 9999.
